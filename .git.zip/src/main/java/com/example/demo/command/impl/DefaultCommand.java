package com.example.demo.command.impl;

import com.example.demo.command.Command;
import jakarta.servlet.http.HttpServletRequest;

import static com.example.demo.command.Attributes.INDEX_JSP;

public class DefaultCommand implements Command {

    @Override
    public String execute(HttpServletRequest request) {
        return INDEX_JSP;
    }
}
