package com.example.demo.entity;

public abstract class AbstractEntity {
}
