package com.example.demo.entity;

public class Item extends AbstractEntity {
}
