package com.example.demo.entity;

public class User extends AbstractEntity {
    // TODO: 18.04.2022 add attributes, getter, setter ... , change DB, (elegant builder)
}
